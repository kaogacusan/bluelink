Inter (Latin, variable) is the font in the app. Turn on cv05, cv11 and ss03.
JetBrains Mono is free on Google Fonts: https://fonts.google.com/specimen/JetBrains+Mono
Both are under the SIL Open Font License.
